# Flowerwall-CRT-shader-for-Godot
My take on a CRT Shader for Godot, inspired by CRT-Royale.

How to use: just enable the plugin in your project settings, press F1 in game to configure
